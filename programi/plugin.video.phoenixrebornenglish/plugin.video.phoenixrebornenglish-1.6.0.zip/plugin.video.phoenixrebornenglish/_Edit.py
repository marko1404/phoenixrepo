import xbmcaddon

MainBase = 'https://goo.gl/sAL578'
addon = xbmcaddon.Addon('plugin.video.phoenixrebornenglish')